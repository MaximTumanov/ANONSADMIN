<?php
class JCKToolbarPlugins extends JCKPlugins {
	var $dialog = '0';
	var $htmldataprocessor = '0';
	var $flash = '0';
	var $filebrowser = '0';
	var $save = '0';
	var $toolbar = '1';
	var $about = '0';
	var $jhtmldataprocessor = '1';
	var $jflash = '1';
	var $jfilebrowser = '1';
	var $jsave = '1';
	var $jlink = '0';
	var $jdocumentlistener = '1';
	var $jtoolbar = '0';
	var $safariroverride = '1';
	var $stylesoverride = '1';
	var $jabout = '1';
	var $ajaxoverride = '1';
	var $tableresize = '1';
	var $autofixlink = '1';
	var $multipleclickdialoghandler = '1';
	var $autofixbackgroundimage = '1';
	var $jhtmlencode = '1';
	var $readmore = '1';
	var $jtreelink = '1';
}
?>