<?php
class JCKStartConfig
{
	//set options to 1 for autoload overwise 0 to stop editor autoloading at atartup for component
	//otherwise set blank to tske the global setting
	var $com_content = 1;
	var $com_categories = 1;
	var $com_sections = 1;
}