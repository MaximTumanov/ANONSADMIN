<?php

abstract class linkNodes
{

 	
	public function __construct(){}
		
	public 	function getItems()
	{
		return;
	}
	
	
	public function getLoadLink($node)
	{
		return;
	}
	
	public function getUrl($id, $type)
	{
	 	return;		
	}

}
?>